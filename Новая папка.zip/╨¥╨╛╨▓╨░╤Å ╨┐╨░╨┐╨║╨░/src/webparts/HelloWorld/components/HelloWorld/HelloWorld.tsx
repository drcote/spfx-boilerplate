import * as React from 'react';
import {IHelloWorldWebPartProps} from "../../HelloWorldWebPart";


export const HelloWorld: React.FC<IHelloWorldWebPartProps> = (props) => {
    return (<div>Hello from SPFx with React 17 !!!! Oh</div>)
}