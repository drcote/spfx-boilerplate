define([], function() {
  return {
    "PropertyPaneDescription": "Webpart Properties Pane",
    "BasicGroupName": "Settings group 1"
  }
});