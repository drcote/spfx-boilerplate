import 'reflect-metadata';
import {container} from 'tsyringe';

export const configContainer: any = () => {

};