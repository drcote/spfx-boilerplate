declare const styles: {
    container: string;
};
export default styles;
