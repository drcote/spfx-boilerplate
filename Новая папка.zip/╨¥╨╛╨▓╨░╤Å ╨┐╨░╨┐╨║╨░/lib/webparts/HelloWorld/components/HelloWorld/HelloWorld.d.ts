import * as React from 'react';
import { IHelloWorldWebPartProps } from "../../HelloWorldWebPart";
export declare const HelloWorld: React.FC<IHelloWorldWebPartProps>;
