/// <reference types="react" />
declare function App(): JSX.Element;
export default App;
