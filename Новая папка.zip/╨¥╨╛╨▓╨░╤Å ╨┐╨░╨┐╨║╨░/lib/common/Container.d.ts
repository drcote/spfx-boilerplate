import 'reflect-metadata';
export declare const configContainer: any;
